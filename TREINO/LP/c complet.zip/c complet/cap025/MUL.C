mul(int a, int b)
{
}
