int sum;
int add(int a, int b);
void main(void)
{
  sum = add(10, 12);
}

add(int a, int b)
{
  int t;

  t = a+b;
  return t;
}
