#include <stdio.h>

void main(int argc, char *argv[])
{
  if(remove(argv[1])) printf ("erro de remo��o\n");
}
