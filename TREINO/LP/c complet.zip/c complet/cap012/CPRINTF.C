#include <conio.h>

void main(void)
{
  cprintf("Eu gosto de C");
}
