#include <conio.h>

void main(void)
{
  char str[80];
  cprintf("digite uma string: ");
  cscanf("%s", str);
  cprintf(str);
}
