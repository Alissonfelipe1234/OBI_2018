#include <conio.h>

void main(void)
{
  cputs("isto � um teste");
}
