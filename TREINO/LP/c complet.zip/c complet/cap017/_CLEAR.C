#include <graph.h>

void main(void)
{
  _clearscreen(_GCLEARSCREEN);
}
