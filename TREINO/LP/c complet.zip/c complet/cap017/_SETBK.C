#include <graph.h>
#include <conio.h>

void main(void)
{
  _setbkcolor(3L);
  _outtext("isto est� sobre azul claro");
  getche();
}
