#include <graph.h>
#include <conio.h>

void main(void)
{
  int i;

  _settextwindow(1, 1, 5, 40);

  for(i=0; i<100; i++)
    _outtext("isto � um teste ");
}
