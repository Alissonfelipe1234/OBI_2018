/* Isto est� certo */
void main(void)
{
  int x, num[100];

  for(x=0; x<100; ++x) num[x]=x;
}
