int j;

void main(void)
{
  register int i;

  for(i=0; i<100; i++) ;

  for(j=0; j<100; j++) ;
}
