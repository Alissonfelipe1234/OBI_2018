max(int a, int b);

void main(void)
{
  int x;

  x = max(10, 20);
}

max(int a, int b)
{
  return a>b ? a : b;
}
