#include <stdlib.h>

void main(void)
{
  system("dir");
}
