#include <stdlib.h>
#include <stdio.h>

void main(void)
{
  int i;

  for(i=0; i<10; i++)
    printf("%d ", rand());
}
