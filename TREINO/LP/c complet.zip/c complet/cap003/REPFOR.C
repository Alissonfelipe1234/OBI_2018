#include <stdio.h>

void main(void)
{
  int x;

  for(x=1; x<=100; x++) printf("%d ",x);
}
