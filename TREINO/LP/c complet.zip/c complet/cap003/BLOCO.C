#include <stdio.h>

void main(void)
{
  int i;

  {  /* um bloco de comandos */
     i = 120;
     printf("%d", i);
  }
}
