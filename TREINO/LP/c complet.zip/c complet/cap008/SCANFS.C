#include <stdio.h>

void main(void)
{
  char str[80];

  printf("entre com uma string: ");
  scanf("%s", str);
  printf("eis sua string: %s", str);
}
