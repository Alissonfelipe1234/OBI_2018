#include <stdio.h>

int sample;

void main(void)
{
  printf("%p", &sample);
}
