#include <stdio.h>

void main(void)
{
  printf("justificado a direita:%8d\n", 100);
  printf("justificado a esquerda:%-8d\n",100);
}
