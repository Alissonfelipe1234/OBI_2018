#include <stdio.h>

void main(void)
{
  printf("%.4f\n", 123.1234567);
  printf("%3.8d\n", 1000);
  printf("%10.15s\n", "Esse � um teste simples.");
}
