#include <stdio.h>

void main(void)
{
  int count;

  printf("isso%n � um teste\n", &count);
  printf("%d", count);
}

