#include <stdio.h>

void main(void)
{
  int i, j;

  scanf("%o%x", &i, &j);
  printf("%o %x", i, j);
}
